#ifndef INCLUDED_COM_SUN_STAR_CHART2_COORDINATESYSTEMTYPEID_HPP
#define INCLUDED_COM_SUN_STAR_CHART2_COORDINATESYSTEMTYPEID_HPP

#include "sal/config.h"

#include "com/sun/star/chart2/CoordinateSystemTypeID.hdl"

#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.hxx"


#endif // INCLUDED_COM_SUN_STAR_CHART2_COORDINATESYSTEMTYPEID_HPP
